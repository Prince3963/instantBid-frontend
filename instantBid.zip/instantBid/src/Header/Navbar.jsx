export default function Navbar() {
  return (
    <nav className="flex justify-between items-center p-6 shadow">
      <h1 className="text-2xl font-bold text-blue-600">instantBid</h1>
      <ul className="flex gap-6">
        <li><a href="#about" className="hover:text-blue-600">About</a></li>
        <li><a href="#services" className="hover:text-blue-600">Services</a></li>
        <li><a href="#how" className="hover:text-blue-600">How It Works</a></li>
      </ul>
      {/* <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
        Get Started
      </button> */}
    </nav>
  );
}
