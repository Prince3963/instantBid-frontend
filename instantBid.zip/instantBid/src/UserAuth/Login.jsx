// src/components/Login.js
import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [responseMessage, setResponseMessage] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setResponseMessage("");

    const formData = new FormData();
    formData.append("Email", email);
    formData.append("Password", password);

    try {
      const response = await axios.post("https://localhost:7119/Login", formData);
      console.log("✅ Login success:", response.data);
      setResponseMessage("Login Successful: " + response.data.message);

      // Example: Navigate to dashboard/home after login
      // navigate("/dashboard");

    } catch (error) {
      console.error("❌ Login failed:", error);
      setError("Login Failed. Please try again.");
    }
  };

  const navigateToRegister = () => {
    navigate("/register");
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-blue-100 to-blue-300 pt-20">
      <div className="bg-white shadow-2xl rounded-2xl p-10 w-full max-w-md">
        <h2 className="text-3xl font-bold text-center text-blue-600 mb-6">
          Welcome Back!
        </h2>
        <p className="text-center text-gray-500 mb-8">
          Login to your <span className="font-semibold text-blue-600">instantBid</span> account
        </p>

        <form onSubmit={handleLogin} className="space-y-5">
          <div>
            <label className="block font-medium text-gray-700">Email</label>
            <input
              type="email"
              name="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 mt-1 focus:outline-none focus:ring-2 focus:ring-blue-400"
              required
            />
          </div>

          <div>
            <label className="block font-medium text-gray-700">Password</label>
            <input
              type="password"
              name="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 mt-1 focus:outline-none focus:ring-2 focus:ring-blue-400"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-all"
          >
            Login
          </button>
        </form>

        {responseMessage && (
          <p className="text-green-600 text-center mt-4 font-semibold">{responseMessage}</p>
        )}
        {error && (
          <p className="text-red-600 text-center mt-4 font-semibold">{error}</p>
        )}

        <div className="text-center text-sm mt-6">
          Don't have an account?{" "}
          <span
            className="text-blue-600 font-medium cursor-pointer hover:underline"
            onClick={navigateToRegister}
          >
            Register
          </span>
        </div>
      </div>
    </div>
  );
};

export default Login;
