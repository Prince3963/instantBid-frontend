import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import Login from './UserAuth/Login';
import Registration from './UserAuth/Registration';
import Navbar from './Header/Navbar';
import Home from './UserAuth/Home';

function App() {
  return (
    <BrowserRouter>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />   
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Registration />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
